//
//  HDCoverageSFramework.h
//  HDCoverageSFramework
//
//  Created by denglibing on 2022/2/24.
//

#import <Foundation/Foundation.h>

#import "HDOCSFramework.h"


//! Project version number for HDCoverageSFramework.
FOUNDATION_EXPORT double HDCoverageSFrameworkVersionNumber;

//! Project version string for HDCoverageSFramework.
FOUNDATION_EXPORT const unsigned char HDCoverageSFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HDCoverageSFramework/PublicHeader.h>


