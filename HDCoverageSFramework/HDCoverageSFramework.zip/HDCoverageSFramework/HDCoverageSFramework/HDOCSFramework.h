//
//  HDOCSFramework.h
//  HDCoverageSFramework
//
//  Created by denglibing on 2022/2/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HDOCSFramework : NSObject

+ (void)frameworkOCStaticFrameworkAction:(NSInteger)tag;

@end

NS_ASSUME_NONNULL_END
