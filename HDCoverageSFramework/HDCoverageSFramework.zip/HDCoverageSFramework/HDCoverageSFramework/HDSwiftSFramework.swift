//
//  HDSwiftSFramework.swift
//  HDCoverageSFramework
//
//  Created by denglibing on 2022/2/24.
//

import Foundation

public struct HDSwiftSFramework {
    public static func outSFrameworkSwiftAction(_ tag: Int) {
        if (tag == 1) {
            print("outSFrameworkSwiftAction: 1")
        }
        else if (tag == 2) {
            print("outSFrameworkSwiftAction: 2")
        }
        else if (tag == 3) {
            print("outSFrameworkSwiftAction: 3")
        }
    }
}
